char pcap_version[] = "1.7.4";
